import { Component } from '@angular/core';

@Component({
  selector: 'app-modals-scheduling',
  standalone: true,
  imports: [],
  templateUrl: './modals-scheduling.component.html',
  styleUrl: './modals-scheduling.component.css'
})
export class ModalsSchedulingComponent {

}
