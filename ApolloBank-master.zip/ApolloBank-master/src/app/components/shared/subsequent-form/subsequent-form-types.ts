export type SubsequentFormType = {
    cep: string;
    uf: string;
    cidade: string;
    logradouro: string;
    complemento: string;
    bairro: string;
    number: string;
    policies: boolean;
}