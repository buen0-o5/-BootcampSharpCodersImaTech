export type FormTypes = {
    name: string;
    ddd: string;
    phone: string;
    email: string;
    cpf: string;
    birthday: string;
    password: number;
    confirmPassword: number;
}