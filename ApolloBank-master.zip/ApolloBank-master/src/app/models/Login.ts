export interface Login {
    cpf: string; 
    password: string;
}

