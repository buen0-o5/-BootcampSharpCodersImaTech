export interface UserLogged {
  $id: string;
  token: string;
  userName: string;
  balance: number;
  accountNumber: number;
  accountId: number;
}
