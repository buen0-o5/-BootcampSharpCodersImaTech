﻿namespace ApolloBank.SampleScheduler.Factories.Interface
{
    public interface IServiceScopeFactory
    {
        IServiceScope CreateScope();
    }
}
