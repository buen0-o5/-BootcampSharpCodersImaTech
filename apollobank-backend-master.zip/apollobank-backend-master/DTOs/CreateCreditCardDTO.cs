﻿using System.ComponentModel.DataAnnotations;

namespace ApolloBank.DTOs
{
    public class CreateCreditCardDTO
    {
        public int AccountId { get; set; }
    }
}
                