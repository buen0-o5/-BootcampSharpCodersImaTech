﻿namespace ApolloBank.Enums
{
    public enum InvoiceStatus
    {
        PENDING = 1,
        PAIDOUT = 2,
        OVERDUE = 3
    }
}
