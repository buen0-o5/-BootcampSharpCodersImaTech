
namespace ApolloBank.Services.Interfaces
{
    public interface IRandomNumber
    {
    }
}