namespace ApolloBank.Services.Interfaces
{
    public interface IHashService
    {
        string HashPassword(string password);
    }
}